#include <stdio.h>
#include <stdlib.h>
#include <math.h>

//Uebung2Aufgabe3
int main()
{
    int p,q;
    printf("Bitte einen Wert f�r p und q eingeben:");
    scanf("%d %d",&p,&q);

    float wurzelterm = ((p/2.0)*(p/2.0)) - q;

    wurzelterm < 0 ? printf("Keine Loesung"), exit(-1)  : 0;

    wurzelterm == 0 ? printf("Eine Loesung: %.2f", -(p/2.0)), exit(0) : 0;

    float wurzel = sqrt(wurzelterm);

    float x1 = -(p/2.0) + wurzel;
    float x2 = -(p/2.0) - wurzel;

    printf("Zwei Loesungen x1 = %.2f und x2 = %.2f", x1 ,x2);

    return 0;
}
