#include <stdio.h>
#include <stdlib.h>


//�bung 2 Aufgabe 1
int main()
{
    int radius;
    printf("Geben Sie einen Radius ein: ");
    scanf("%d", &radius);

    float pi = 3.1415;
    float umfang, flaeche;

    umfang = 2 * pi * radius;
    flaeche = pi * radius * radius;

    printf("Der Umfang betraegt %.2f", umfang);
    printf("\nDie Flaeche betraegt %.2f", flaeche);

    return 0;
}
