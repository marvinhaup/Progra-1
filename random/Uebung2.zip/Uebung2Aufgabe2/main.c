#include <stdio.h>
#include <stdlib.h>
#include <math.h>

//�bung 2 Aufgabe 2
int main()
{
    int eingabe;
    printf("Gib eine Anzahl an Tagen ein: ");
    scanf("%d", &eingabe);



    int jahre,wochen,tage;

    jahre = eingabe / 365;
    wochen = (eingabe % 365) / 7;
    tage = eingabe - ((jahre * 365)+(wochen*7));

    printf("Jahre: %d, Wochen: %d, Tage: %d",jahre,wochen,tage);

    return 0;
}
