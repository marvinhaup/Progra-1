#include <stdio.h>
#include <stdlib.h>

//�bung 1 Aufgabe 2
int main()
{
    float groesse = 1.78;
    int gewicht;
    printf("Geben sie ihr Gewicht ein:");
    scanf("%d", &gewicht);
    float bmi = gewicht / (groesse * groesse);
    printf("Der BMI betraegt: %f", bmi);
    return 0;
}
