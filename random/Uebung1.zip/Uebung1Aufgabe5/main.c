#include <stdio.h>
#include <stdlib.h>

//�bung 1 Aufgabe 5
int main()
{
    char b1, b2;
    char trash;

    printf("Geben Sie Buchstabe 1 ein: ");
    scanf("%c", &b1);

    printf("Geben Sie Buchstabe 2 ein: ");
    scanf("\n%c", &b2);

    printf("\nDie ASCII-Codes der beiden Zeichen sind %d und %d", b1, b2);
    return 0;
}
