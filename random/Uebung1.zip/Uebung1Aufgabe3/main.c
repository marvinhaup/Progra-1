#include <stdio.h>
#include <stdlib.h>

//�bung 1 Aufgabe 3
int main()
{
    float preis;
    printf("Gib einen Preis ein: ");
    scanf("%f", &preis);

    printf("Du hast den Preis %.2f eingegeben", preis);

    return 0;
}
