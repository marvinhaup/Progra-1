#include <stdio.h>
#include <stdlib.h>

//�bung 1 Aufgabe 4
int main()
{
    int tag, monat, jahr;
    printf("Geben Sie ein Datum ein [TT.MM.JJJJ]: ");
    scanf("%d.%d.%d",&tag,&monat,&jahr);

    printf("Dein intern. Datum ist: %d-%d-%d",jahr,monat,tag);

    return 0;
}
